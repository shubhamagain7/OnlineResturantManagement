﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using Resturant_Api.Controllers;
using Resturant_Api.Models;
using Resturant_Api.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NUnit_Resturant
{
    class MenuTest
    {
        ResturantContext db = new ResturantContext();
        [SetUp]
        public void SetUp()
        {
            var Foods = new List<Menu>
            {
                new Menu{Id = 1, Name = "Mixed Fried Rice" , Price = 120, Type = "Non Veg"},
                new Menu{Id = 2,Name = "Veg Fried Rice" , Price = 80, Type = "Veg"},
                new Menu{Id = 3, Name = "Chicken Fried Rice" , Price = 10, Type = "Non Veg"}

                };
            var Foodsdata = Foods.AsQueryable();
            var mockSet = new Mock<DbSet<Menu>>();
            mockSet.As<IQueryable<Menu>>().Setup(m => m.Provider).Returns(Foodsdata.Provider);
            mockSet.As<IQueryable<Menu>>().Setup(m => m.Expression).Returns(Foodsdata.Expression);
            mockSet.As<IQueryable<Menu>>().Setup(m => m.ElementType).Returns(Foodsdata.ElementType);
            mockSet.As<IQueryable<Menu>>().Setup(m => m.GetEnumerator()).Returns(Foodsdata.GetEnumerator());

            var mockContext = new Mock<ResturantContext>();

            mockContext.Setup(c => c.Menu).Returns(mockSet.Object);

            db = mockContext.Object;


        }
        [Test]

        public void GetMenu()
        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            var data = controller.GetUsers();
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }

        [Test]

        public void GetByMenuIdPositive()
        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            var data = controller.GetUser(1);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }



        [Test]

        public void GetByFoodIdNegative()

        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            var data = controller.GetUser(52);
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);

        }

        [Test]

        public void PostUser()
        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            Menu food = new Menu { Id = 4, Name = "Roti", Price = 20, Type = "Veg" };
            var data = controller.Post(food);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }



        [Test]

        public void DeleteUserPositive()
        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            var data = controller.Delete(2);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }

        [Test]
        public void DeleteUserNegative()
        {
            var repo = new Mock<MenuRep>(db);
            MenusController controller = new MenusController(repo.Object);
            var data = controller.Delete(25);
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);



        }



    }
}
