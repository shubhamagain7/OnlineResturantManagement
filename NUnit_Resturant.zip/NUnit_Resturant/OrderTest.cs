﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using Resturant_Api.Controllers;
using Resturant_Api.Models;
using Resturant_Api.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NUnit_Resturant
{
    class OrderTest
    {
        ResturantContext db = new ResturantContext();
        [SetUp]
        public void SetUp()
        {
            var Orders = new List<Order>
                {
                new Order{PhoneNo = "2121464" ,FoodId = 1, OrderId = 8},
                new Order{PhoneNo = "123456" ,FoodId = 2, OrderId = 9},
                new Order{PhoneNo = "4544545" ,FoodId = 3, OrderId = 10}

                };
            var Ordersdata = Orders.AsQueryable();
            var mockSet = new Mock<DbSet<Order>>();
            mockSet.As<IQueryable<Order>>().Setup(m => m.Provider).Returns(Ordersdata.Provider);
            mockSet.As<IQueryable<Order>>().Setup(m => m.Expression).Returns(Ordersdata.Expression);
            mockSet.As<IQueryable<Order>>().Setup(m => m.ElementType).Returns(Ordersdata.ElementType);
            mockSet.As<IQueryable<Order>>().Setup(m => m.GetEnumerator()).Returns(Ordersdata.GetEnumerator());

            var mockContext = new Mock<ResturantContext>();

            mockContext.Setup(c => c.Orders).Returns(mockSet.Object);

            db = mockContext.Object;


        }
        [Test]

        public void GetOrders()
        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            var data = controller.GetUsers();
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }

        [Test]

        public void GetByOrderIdPositive()
        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            var data = controller.GetUser(9);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }



        [Test]

        public void GetByOrderIdNegative()

        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            var data = controller.GetUser(52);
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);

        }

        [Test]

        public void PostUser()
        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            Order order = new Order { PhoneNo = "442242424", FoodId = 4, OrderId = 11 };
            var data = controller.Post(order);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }



        [Test]

        public void DeleteUserPositive()
        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            var data = controller.Delete(10);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }

        [Test]
        public void DeleteUserNegative()
        {
            var repo = new Mock<OrderRep>(db);
            OrdersController controller = new OrdersController(repo.Object);
            var data = controller.Delete(66);
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);



        }
    }



}

