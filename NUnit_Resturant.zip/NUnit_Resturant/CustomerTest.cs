using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using Resturant_Api.Controllers;
using Resturant_Api.Models;
using Resturant_Api.Repository;
using System.Collections.Generic;
using System.Linq;

namespace NUnit_Resturant
{
    public class Tests
    {
        ResturantContext db = new ResturantContext();
        [SetUp]
        public void Setup()
        {
            var Users = new List<Customer>
                {
                 new Customer{ FirstName="biswarup",LastName="mazumdar",PhoneNo="213213465",Password="1232"},
                new Customer{FirstName="prithwiman",LastName="mazumdar",PhoneNo="314454",Password="65843"},
                new Customer{FirstName="subham",LastName="debnath",PhoneNo="00112345",Password="gh63"}

                    };

            var Usersdata = Users.AsQueryable();
            var mockSet = new Mock<DbSet<Customer>>();
            mockSet.As<IQueryable<Customer>>().Setup(m => m.Provider).Returns(Usersdata.Provider);
            mockSet.As<IQueryable<Customer>>().Setup(m => m.Expression).Returns(Usersdata.Expression);
            mockSet.As<IQueryable<Customer>>().Setup(m => m.ElementType).Returns(Usersdata.ElementType);
            mockSet.As<IQueryable<Customer>>().Setup(m => m.GetEnumerator()).Returns(Usersdata.GetEnumerator());

            var mockContext = new Mock<ResturantContext>();

            mockContext.Setup(c => c.Customers).Returns(mockSet.Object);

            db = mockContext.Object;
        }

        [Test]

        public void GetUsers()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            var data = controller.GetUsers();
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }

        [Test]

        public void GetByPhonePositive()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            var data = controller.GetUser("314454");
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }



        [Test]

        public void GetByPhoneNegative()

        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            var data = controller.GetUser("656546546");
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);

        }

        [Test]

        public void PostCustomer()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            Customer user = new Customer { FirstName = "Dishani", LastName = "Das", PhoneNo = "31464", Password = "632" };
            var data = controller.Post(user);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }
        [Test]

        public void PutUserPositive()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            Customer user = new Customer { FirstName = "Prithwi", LastName = "Mazumdar" };
            var data = controller.Put("00112345", user);
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);

        }

        [Test]

        public void PutUserNegative()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
           Customer user = new Customer { FirstName = "Dishani", LastName = "Das" };
            var data = controller.Put("12356", user);
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);

        }

        [Test]

        public void DeleteUserPositive()
        {
            var repo = new Mock<CustomerRep>(db);
            CustomersController controller = new CustomersController(repo.Object);
            var data = controller.Delete("00112345");
            var result = data as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }

        [Test]
        public void DeleteUserNegative()
        {
            var repo = new Mock<CustomerRep>(db);
          CustomersController controller = new CustomersController(repo.Object);
            var data = controller.Delete("35165465464");
            var result = data as ObjectResult;
            Assert.AreEqual(400, result.StatusCode);


        }
    }
}