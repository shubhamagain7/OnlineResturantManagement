﻿using ResturantMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResturantMVC.ViewModels
{
    public class MenuViewModel
    { public string PhoneNo { get; set; }
       public IEnumerable<Menu> menus { get; set; }



    }
}
