﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ResturantMVC.Models;

namespace ResturantMVC.Controllers
{
    public class OrdersController : Controller
    {
        Uri base_address = new Uri("https://localhost:44329/api");

        HttpClient client;
        public OrdersController()
        {
            client = new HttpClient();
            client.BaseAddress = base_address;
        }
        public IActionResult PlaceOrder(string CustomerId,int MenuId)
        {
            Order obj = new Order { PhoneNo = CustomerId, FoodId = MenuId };
            string data = JsonConvert.SerializeObject(obj);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/orders", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("MenuList","Menus", new { PhoneNo = CustomerId });

            }
            return View();
        }
        public IActionResult MyOrder(string PhoneNo)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/orders").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
               IEnumerable <Order> orders = JsonConvert.DeserializeObject<List<Order>>(data);
                orders = from o in orders where o.PhoneNo == PhoneNo select o;
                return View(orders);

            }
            return View();

        }
    }
}