﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ResturantMVC.Models;
using ResturantMVC.ViewModels;

namespace ResturantMVC.Controllers
{
    public class MenusController : Controller
    {
        Uri base_address = new Uri("https://localhost:44329/api");

        HttpClient client;
        public MenusController()
        {
            client = new HttpClient();
            client.BaseAddress = base_address;
        }
        public IActionResult MenuList(string PhoneNo)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/menus/" ).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                List<Menu> m= JsonConvert.DeserializeObject<List<Menu>>(data);
                MenuViewModel view = new MenuViewModel
                {
                    PhoneNo = PhoneNo,
                    menus = m
                };
                return View(view);
            }
            return View();
        }
    }
}