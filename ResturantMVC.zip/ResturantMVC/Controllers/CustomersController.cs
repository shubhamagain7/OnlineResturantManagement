﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ResturantMVC.Models;

namespace ResturantMVC.Controllers
{
    public class CustomersController : Controller
    {
        Uri base_address = new Uri("https://localhost:44329/api");

        HttpClient client;
        public CustomersController()
        {
            client = new HttpClient();
            client.BaseAddress = base_address;
        }
        public IActionResult New()
        {
            return View();
        }
    
        public IActionResult Create(Customer customer)
        {
            string data = JsonConvert.SerializeObject(customer);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/customers", content).Result;
            if(response.IsSuccessStatusCode)
            {
                return RedirectToAction("Details", new  { PhoneNo = customer.PhoneNo });
            }
            return View();
        }

        public IActionResult Details(string PhoneNo)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/customers/" + PhoneNo).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Customer customer = JsonConvert.DeserializeObject<Customer>(data);
                return View(customer);
            }
            return View();

        }
        public IActionResult Edit(string PhoneNo)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/customers/" + PhoneNo).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Customer customer = JsonConvert.DeserializeObject<Customer>(data);
                return View(customer);
            }
            return View();

          
        }
        public IActionResult Update(Customer customer)
        {
            string data = JsonConvert.SerializeObject(customer);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/customers/"+ customer.PhoneNo, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Details", new { PhoneNo = customer.PhoneNo });
            }
            return View();
        }

    }
}